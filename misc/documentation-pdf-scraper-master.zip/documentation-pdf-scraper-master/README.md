# Harvest

A small Scrapy project to recursively traverse a site, downloading all pages as PDF.

```bash
scrapy crawl harvest -o pages.csv -t csv
```
