import scrapy
import re
import os
import urllib.parse
import logging
import time
from playwright.async_api import async_playwright
from playwright._impl._errors import TimeoutError
from bs4 import BeautifulSoup

output_directory = "pdf"
#
try:
    os.mkdir(output_directory)
except FileExistsError:
    pass

LINK_BLACKLIST = [
    "\\.parquet$",
    "\\.tf$",
    "\\.sh$",
    "\\.yaml$",
    "\\.png$",
]


def generate_file_name_from_url(url, ext=".pdf"):
    path = urllib.parse.urlparse(url).path
    path = path.strip("/")
    path = path.replace("/", "_")

    if not path:
        path = "index"

    return path + ext


# CSS to hide sidebar.
#
custom_css = """
section.main-content {
    margin-left: 0;
}

aside {
    display: none;
}
"""


class WebsiteSpider(scrapy.Spider):
    name = "harvest"
    allowed_domains = ["docs.dominodatalab.com"]
    start_urls = ["https://docs.dominodatalab.com/"]

    async def parse(self, response):
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()

            pdf = generate_file_name_from_url(response.url)

            logging.info(f"🟢 Open {response.url}.")
            while True:
                try:
                    await page.goto(response.url)
                    break
                except Exception as error:
                    error = str(error)
                    if "ERR_NETWORK_CHANGED" in error:
                        logging.warning("Network changed.")
                    elif "ERR_CONNECTION_RESET" in error:
                        logging.warning("Network connection reset.")
                    elif isinstance(error, TimeoutError):
                        logging.warning("Timeout error.")
                        time.sleep(60)
                    else:
                        raise

            await page.wait_for_load_state("domcontentloaded")
            await page.wait_for_selector("h1")

            type = await page.evaluate("() => {return document.contentType;}")
            logging.info(f"- type: {type}")
            if type == "text/html":
                await page.evaluate("document.body.style.zoom=0.75")
                await page.add_style_tag(content=custom_css)
                await page.pdf(path=os.path.join(output_directory, pdf))

                html = await page.content()

            await page.close()
            await browser.close()

        if type == "text/html":
            soup = BeautifulSoup(html, "lxml")

            for link in soup.find_all("a"):
                try:
                    link = link["href"]
                except KeyError:
                    logging.warning("Link without href attribute.")
                    continue
                # Strip anchor.
                link = re.sub("#.*$", "", link)
                # Check for relative links.
                if link.startswith("/") or self.allowed_domains[0] in link:
                    # Only follow if not on blacklist.
                    for pattern in LINK_BLACKLIST:
                        if re.search(pattern, link):
                            logging.warning("⛔ Link is blacklisted.")
                            break
                    else:
                        yield response.follow(link, callback=self.parse)

            url_split = re.split("/", response.url)

            title = soup.find("h1")
            try:
                category = url_split[3]
                if category != "release_notes":
                    category = url_split[5]
            except IndexError:
                category = None
            try:
                version = url_split[4]
            except IndexError:
                version = None

            yield {
                "url": response.url,
                "category": category,
                "version": version,
                "title": title.string,
                "pdf": pdf,
            }
