import json
import os
from collections import defaultdict
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Dict, List, NamedTuple, Optional, Tuple, Type, Union

import requests
import rich_click as click

from flytekitplugins.domino.task import (
    ClusterProperties,
    DatasetSnapshot,
    DominoJobConfig,
    DominoJobTask,
    EnvironmentRevisionSpecification,
    EnvironmentRevisionType,
    ExternalDataVolume,
    GitRef,
)


class DominoFlyteException(Exception):
    pass


def retrieve_valid_properties(project_id: Optional[str] = None, page_size: Optional[int] = None):
    if not project_id:
        project_id = os.environ['FLYTE_DEFAULT_PROJECT']

    url = f"{os.environ['DOMINO_API_PROXY']}/v4/jobs/{project_id}/retrieveValidProperties"

    params = {}
    # Page size determines the number of environments and revisions per environment. Defaults to 10.
    if page_size:
        params["pageSize"] = page_size

    response = requests.get(url, params=params)
    if response.status_code != 200:
        raise DominoFlyteException(
            f"Failed to retrieve job properties (StatusCode {response.status_code}): {response.text})"
        )

    pretty = json.dumps(response.json(), indent=2)

    click.secho(f"Available job properties:\n{pretty}")


@dataclass
class Input:
    """
    An input for a DominoJobTask.
    User code (from the `command` provided to the DominoJobTask) must read the value from the workflows inputs directory.

    Example initialization for a DominoJobTask that takes an integer input named "my_integer":
    Input(name="my_integer", type=int, value=13)

    Example user code (from the `command` provided to the DominoJobTask) to read the value of the input:
    with open("/workflow/inputs/my_integer", "r") as my_integer_input_file:
        my_integer = int(my_integer_input_file.read()) # my_integer var is now 13 and can be used in the rest of your `command` code

    :param name: The name of the input. When used in a DominoJobTask, this name will appear in the Flyte UI as the name of an
        input to the task.
    :param type: The programmatic type of the input. When used in a DominoJobTask, this type will appear in the Flyte UI as the
        type of an input to the task.
    :param value: The value of the input. When used in a DominoJobTask, this value will be passed to the task for the associated
        input name, and the value will appear in the Flyte UI.
    """

    name: str
    type: Type
    value: Any


@dataclass
class Output:
    """
    The name and type of an output to be produced by a DominoJobTask.
    This defines an output contract and does not have the value of the output.
    The value is obtained by running the DominoJobTask, and user code (from the `command` provided to the DominoJobTask)
    must write the value of the output to the workflows outputs directory.

    Example initialization for a DominoJobTask that produces an integer output named "the_answer":
    Output(name="the_answer", type=int)

    Example user code (from the `command` provided to the DominoJobTask) to write the output for the above Output:
    with open("/workflow/outputs/the_answer", "w+") as the_answer_output_file:
        the_answer = 42 # note that this value can be produced dynamically by the preceeding logic in your code
        the_answer_output_file.write(str(the_answer))
        # the_answer output 42 will be available in the Flyte UI when the task completes.
        # When building a Flyte workflow using python, the promised value is in the DominoJobTaskOutputPromise
        # returned from a run_domino_job_task() call. This promised value can be used as an input value to a subsequent task.

    :param name: The name of the output. When used in a DominoJobTask, this name will appear in the Flyte UI as the name of an
        output from the task.
    :param type: The programmatic type of the output. When used in a DominoJobTask, this type will appear in the Flyte UI as the
        type of an output from the task.
    """

    name: str
    type: Type


DominoJobTaskOutputPromise = NamedTuple
"""
The return type of `run_domino_job_task()`, which is the return type of running a DominoJobTask instance.
Type-aliased to make clear that this is promised output, not the actual output.
Actually, a DominoJobTask is an async flyte task which returns the type flytekit.core.promise.create_task_output.<locals>.Output:
https://github.com/flyteorg/flytekit/blob/f4d894af2ebb66f4492506ebb121509ef8cb8aa3/flytekit/core/promise.py#L644
But, it very tricky (impossible?) to use that type correctly outside of the Flyte code because that is a local class: https://bugs.python.org/issue42824
And essentially it is just a NamedTuple, so we'll alias that.
"""


def run_domino_job_task(
    flyte_task_name: str,
    command: str,
    job_title: Optional[str] = None,
    use_project_defaults_for_omitted: bool = False,
    dfs_repo_commit_id: Optional[str] = None,
    main_git_repo_ref: Optional[GitRef] = None,
    environment_name: Optional[str] = None,
    environment_id: Optional[str] = None,
    environment_revision_id: Optional[str] = None,
    hardware_tier_name: Optional[str] = None,
    hardware_tier_id: Optional[str] = None,
    inputs: Optional[List[Input]] = None,
    output_specs: Optional[List[Output]] = None,
    volume_size_gib: Optional[int] = None,
    dataset_snapshots: Optional[List[DatasetSnapshot]] = None,
    external_data_volumes: Optional[List[ExternalDataVolume]] = None,
    external_data_volume_ids: Optional[List[str]] = None,
    compute_cluster_properties: Optional[ClusterProperties] = None,
    cache: bool = False,
    cache_version: str = "",
    cache_ignore_input_vars: Tuple[str, ...] = (),
    retries: int = 0,
    timeout: Union[timedelta, int] = timedelta(hours=3),
) -> DominoJobTaskOutputPromise:
    """
    Runs a DominoJobTask (a Flyte task that runs a Domino job) and returns the outputs (if any) produced by the DominoJobTask.

    Example usage in a Flyte workflow where output of one `run_domino_job_task()` is input to a subsequent `run_domino_job_task()`:

    ```
    @workflow
    def training_workflow(data_path: FlyteFile="/mnt/code/data/data.csv") -> FlyteFile:
        '''
        Sample data preparation and training workflow

        This workflow accepts a path to a CSV for some initial input and simulates
        the processing of the data and usage of the processed data in a training job.

        :param data_path: str: Path of the CSV file data to use as input to data prep (results of which are used in downstream training).
        :return: FlyteFile: A reference to the file containing the model produced by the training.
        '''
        # define inputs using the Input helper class
        data_prep_inputs = [
            Input(name="data_path", type=FlyteFile, value=data_path)
        ]
        # define output specs using the Output helper class. this is the contract for what the job will produce as output.
        processed_data_output_name = "processed_data"
        processed_data_output_spec = Output(name=processed_data_output_name, type=FlyteFile)
        data_prep_output_specs = [
            processed_data_output_spec
        ]
        # run the data prep task to get the promised output values
        promised_data_prep_outputs = run_domino_job_task(
            flyte_task_name="Prepare data",
            command="python /mnt/code/python/prep-data.py",
            # example specifying all Domino Job properites (instead of project defaults)
            # values for each param can be looked up using helper retrieve_valid_properties()
            use_project_defaults_for_omitted=False,
            environment_id="6603001e0db28c35bc115868",
            environment_revision_id="6603001e0db28c35bc11586b",
            hardware_tier_id="large-k8s",
            volume_size_gib=20,
            dataset_snapshots=[DatasetSnapshot("id-1", 1)],
            external_data_volume_ids=["edv-id-1", "edv-id-2"],
            inputs=data_prep_inputs,
            output_specs=data_prep_output_specs
        )

        training_inputs = [
            # get a promised output value from the data prep output to use as input to the training task
            Input(
                **dataclasses.asdict(processed_data_output_spec), # convenience to use same name and type without repeating strings
                value=getattr(promised_data_prep_outputs, processed_data_output_name)
            ),
            Input(name="epochs", type=int, value=10),
            Input(name="batch_size", type=int, value=32)
        ]
        training_output_specs = [
            Output(name="model", type=FlyteFile)
        ]
        # final output with name "model" and URL reference to model file will be available in the Flyte UI after the training task completes
        return run_domino_job_task(
            flyte_task_name="Train model",
            command="python /mnt/code/python/train.py",
            # example passing environment and hardware tier name. uses project defaults for everything else that has a default
            use_project_defaults_for_omitted=True,
            environment_name="Training Environment",
            hardware_tier_name="Large - Dask",
            # valid compute_cluster_properties can be looked up using helper retrieve_valid_properties()
            compute_cluster_properties=ClusterProperties(ComputeClusterType.Dask, "compute-env-id-1", "worker-hwt-id-1", 5)
            inputs=training_inputs,
            output_specs=training_output_specs
        )
    ```

    :param flyte_task_name: str: The name of the Flyte task that will run the Domino Job. Shown in the Flyte UI.
    :param command: str: The command the Domino Job should run. Example: "python /mnt/code/python/train.py"
    :param job_title: Optional[str]: The title of the Domino Job. Will appear in the Title column on the Domino Job dashboard.
        If not provided, the title will be the same as the param `flyte_task_name`.
    :param use_project_defaults_for_omitted: Optional[bool]: Whether to use the Domino Project defaults for the Domino Job
        for params to this func call that are None and that have a project default. Params that have project defaults are:
        `dfs_repo_commit_id`, `main_git_repo_ref` (if the Project is Git-based), `environment_id`, `environment_is_restricted`,
        `environment_revision_id`, `hardware_tier_id`, `volume_size_gib`, `dataset_snapshots`, and `external_data_volume_ids`.
        If False, those params cannot be None. If True, all of those params that are None will be resolved to the project defaults.
    :param dfs_repo_commit_id: Optional[str]: The commit id of the DFS repo to use for the Domino Job.
        In a DFS-based Domino project, the DFS repo is the main repo. In a Git-based Domino project, the DFS repo contains artifacts.
        If unsure, use helper retrieve_valid_properties() to get commit id you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the latest commit of the main branch of the DFS repo of the Domino Project.
    :param main_git_repo_ref: Optional[GitRef]: The main git repo ref to use for the Domino Job.
        Only valid for Git-based Domino projects.
        If unsure, use helper retrieve_valid_properties() to get the git ref you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the latest commit of the main branch of the Git repo of the Domino Project.
    :param environment_name: Optional[str]: The name of the environment to use for the Domino Job.
        Cannot provide both environment_name and environment_id.
    :param environment_id: Optional[str]: The id of the environment to use for the Domino Job.
        Cannot provide both environment_name and environment_id.
        If unsure, use helper retrieve_valid_properties() to get the id of the environment you want.
        If None and environment_revision_id is not None, the Domino Job will use the environment corresponding to the environment revision id.
        If None and environment_revision_id is None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default for the Domino Project.
    :param environment_revision_id: Optional[str]: The id of the environment revision to use for the Domino Job.
        If unsure, use helper retrieve_valid_properties() to get the id of the environment revision you want.
        If None and environment_id is not None, the Domino Job will use the active revision of the provided environment.
        If None and environment_id is None and use_project_defaults_for_omitted is True, the Domino Job will use the latest revision of the configured default env for the Domino Project.
    :param hardware_tier_name: Optional[str]: The name of the hardware tier to use for the Domino Job.
        Cannot provide both hardware_tier_name and hardware_tier_id.
    :param hardware_tier_id: Optional[str]: The id of the hardware tier to use for the Domino Job.
        Cannot provide both hardware_tier_name and hardware_tier_id.
        If unsure, use helper retrieve_valid_properties() to get the id of the hardware tier you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default hardware tier for the Domino Project.
    :param inputs: Optional[List[Input]]: The inputs to the DominoJobTask, which must be read by the Domino Job's user code
        (from the `command` param). See the Input class docstring for more details on how to read/use the value.
    :param output_specs: Optional[List[Output]]: The specs for the outputs from the DominoJobTask, whose values
        are not known until the DominoJobTask completes. The values must be written by the Domino Job's user code (from the `command` param).
        See the Output class docstring for more details on how to write the value in the expected way.
    :param volume_size_gib: Optional[int]: The size of the volume in GiB to use for the Domino Job. Min: 4. Max: 200.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default volume size for the Domino Project.
    :param dataset_snapshots: Optional[List[DatasetSnapshot]]: List of DatasetSnapshots to mount to the Domino Job.
        If unsure, use helper retrieve_valid_properties() to get the snapshots you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default dataset snapshots for the Domino Project.
        If use_project_defaults_for_omitted is False and you want to mount no dataset snapshots, pass an empty list.
    :param external_data_volumes: Optional[List[ExternalDataVolume]]: List of External Data Volumes (EDVs) to mount to the Domino Job.
        Cannot provide both external_data_volumes and external_data_volume_ids (external_data_volume_ids still accepted for backwards compatibility).
        If unsure, use helper retrieve_valid_properties() to get the names and/or ids of the EDVs you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default EDVs for the Domino Project.
        If use_project_defaults_for_omitted is False and you want to mount no EDVs, pass an empty list.
    :param external_data_volume_ids: Optional[List[str]]: List of ids of External Data Volumes (EDVs) to mount to the Domino Job.
        Cannot provide both external_data_volumes and external_data_volume_ids (external_data_volume_ids still accepted for backwards compatibility).
        If unsure, use helper retrieve_valid_properties() to get the ids of the EDVs you want.
        If None and use_project_defaults_for_omitted is True, the Domino Job will use the configured default EDVs for the Domino Project.
        If use_project_defaults_for_omitted is False and you want to mount no EDVs, pass an empty list.
    :param compute_cluster_properties: Optional[ClusterProperties]: The properties of the compute cluster to use for the Domino Job.
        If not provided, the Domino Job will not use a compute cluster.
    :param cache: bool: Boolean that indicates if caching should be enabled.
        If not provided, caching will not be enabled.
    :param cache_version: bool: Cache version to use. Changes to the task signature will automatically trigger a cache miss, but you can always
        manually update this field as well to force a cache miss. You should also manually bump this version if the function body/business logic
        has changed, but the signature hasn’t.
        If not provided, the cache version will be an empty string.
    :param cache_ignore_input_vars: Tuple[str, ...]: Input variables that should not be included when calculating the hash used for caching.
        If not provided, all input variables will be included when calculating the hash.
    :param retries: int: Number of times to retry this task during a workflow execution.
        If not provided, this task will not retry when a failure occurs.
    :param timeout: Union[timedelta, int]: The maximum amount of time for which one execution of this task should be executed for.
        The execution will be terminated if the runtime exceeds the given timeout.
        If not provided, the task will timeout after a default limit of 3 hours.

    :raises ValueError: If the keyword args fail validation.
    :raises requests.exceptions.RequestException: If there is an HTTP communication error while trying to talk to the Domino API
        to resolve info for the task.
    :raises DominoFlyteException: If there is a non-OK response from the Domino API while trying to resolve info for the task.

    :returns: DominoJobTaskOutputPromise: A NamedTuple where each element corresponds to one of the provided `Output` items from the `output_specs` param.
        The name of the tuple element is the name from the matching output spec (`output_spec.name`), and the value of the tuple element is a "promised" value whose type
        is the type from output spec (`output_spec.type`). The actual value is not available until the Flyte task completes, but this promised value can be passed in as a
        value to subsequent Flyte tasks, including as a value to a `DominoTaskInput` in the `inputs` param to `run_domino_job_task()`.
        Since a DominoJobTaskOutputPromise is an alias for a NamedTuple, a promised output value can be accessed in code in various ways:
        - with getattr(): getattr(promised_outputs, output_spec.name) # can use a variable or string literal as the second arg to getattr()
        - with "dot" notation: promised_outputs.output_spec_name # cannot use variable or string after the "."
    """
    kwargs = locals()
    del kwargs["flyte_task_name"]
    _validate_run_domino_job_task_kwargs(flyte_task_name, kwargs)

    if inputs is None:
        inputs = []
    if output_specs is None:
        output_specs = []
    if job_title is None:
        job_title = flyte_task_name

    _env_id, _env_rev_spec = _get_domino_job_config_env_args(
        flyte_task_name, environment_name, environment_id, environment_revision_id
    )

    _hardware_tier_id = _get_domino_job_config_hardware_tier_args(flyte_task_name, hardware_tier_name, hardware_tier_id)

    _dataset_snapshots = _get_domino_job_config_dataset_snapshots_args(flyte_task_name, dataset_snapshots)

    _edv_ids = _get_domino_job_config_edv_args(flyte_task_name, external_data_volumes, external_data_volume_ids)

    domino_job_config = DominoJobConfig(
        Title=job_title,
        Command=command,
        CommitId=dfs_repo_commit_id,
        MainRepoGitRef=main_git_repo_ref,
        EnvironmentId=_env_id,
        EnvironmentRevisionSpec=_env_rev_spec,
        HardwareTierId=_hardware_tier_id,
        VolumeSizeGiB=volume_size_gib,
        DatasetSnapshots=_dataset_snapshots,
        ExternalVolumeMountIds=_edv_ids,
        ComputeClusterProperties=compute_cluster_properties,
    )

    input_name_to_type = {}
    input_name_to_value = {}
    for input in inputs:
        input_name_to_type[input.name] = input.type
        input_name_to_value[input.name] = input.value

    output_name_to_type = {output_spec.name: output_spec.type for output_spec in output_specs}

    domino_job_task = DominoJobTask(
        flyte_task_name,
        domino_job_config,
        use_latest=use_project_defaults_for_omitted,
        inputs=input_name_to_type,
        outputs=output_name_to_type,
        cache=cache,
        cache_version=cache_version,
        cache_ignore_input_vars=cache_ignore_input_vars,
        retries=retries,
        timeout=timeout,
    )
    return domino_job_task(**input_name_to_value)


def _validate_run_domino_job_task_kwargs(flyte_task_name: str, kwargs: Dict[str, Any]):
    validation_err_messages = []
    project_is_git_based = True if os.getenv("DOMINO_IS_GIT_BASED") == "true" else False

    missing_params_err_messages = _validate_run_domino_job_task_kwargs_not_missing_params(project_is_git_based, kwargs)
    validation_err_messages.extend(missing_params_err_messages)

    individual_invalid_err_messages = _validate_individual_run_domino_job_task_kwargs(project_is_git_based, kwargs)
    validation_err_messages.extend(individual_invalid_err_messages)

    incompatible_params_err_messages = _validate_incompatible_run_domino_job_task_kwargs(kwargs)
    validation_err_messages.extend(incompatible_params_err_messages)

    bad_edv_err_messages = _validate_edvs(kwargs)
    validation_err_messages.extend(bad_edv_err_messages)

    if validation_err_messages:
        validation_err_messages.insert(0, f"Flyte task \"{flyte_task_name}\":")
        err_msg = "\n* ".join(validation_err_messages)
        raise ValueError(err_msg)


def _validate_run_domino_job_task_kwargs_not_missing_params(
    project_is_git_based: bool, kwargs: Dict[str, Any]
) -> List[str]:
    if kwargs["use_project_defaults_for_omitted"]:
        return []
    # user did not explicitly say "use proj defaults for omitted", so user must specify certain params
    validation_err_messages = []
    definitely_required_params = {
        "dfs_repo_commit_id",
        "environment_revision_id",
        "volume_size_gib",
        "dataset_snapshots",
    }
    if project_is_git_based:
        definitely_required_params.add("main_git_repo_ref")
    params_that_are_none = {param_name for param_name, value in kwargs.items() if value is None}
    missing_definitely_required_params = definitely_required_params.intersection(params_that_are_none)
    missing_an_env_param = kwargs["environment_id"] is None and kwargs["environment_name"] is None
    missing_a_hwt_param = kwargs["hardware_tier_id"] is None and kwargs["hardware_tier_name"] is None
    missing_an_edv_param = kwargs["external_data_volumes"] is None and kwargs["external_data_volume_ids"] is None
    if missing_definitely_required_params:
        validation_err_messages.append(
            f"use_project_defaults_for_omitted is False, so the following params must not be None: {missing_definitely_required_params}"
        )
    if missing_an_env_param:
        validation_err_messages.append(
            "use_project_defaults_for_omitted is False, so must provide either \"environment_name\" or \"environment_id\" (but not both)"
        )
    if missing_a_hwt_param:
        validation_err_messages.append(
            "use_project_defaults_for_omitted is False, so must provide either \"hardware_tier_name\" or \"hardware_tier_id\" (but not both)"
        )
    if missing_an_edv_param:
        validation_err_messages.append(
            "use_project_defaults_for_omitted is False, so must provide either \"external_data_volumes\" or \"external_data_volume_ids\" (but not both)"
        )
    return validation_err_messages


def _validate_individual_run_domino_job_task_kwargs(project_is_git_based: bool, kwargs: Dict[str, Any]) -> List[str]:
    validation_err_messages = []

    volume_size_gib = kwargs["volume_size_gib"]
    if volume_size_gib is not None and (volume_size_gib < 4 or volume_size_gib > 200):
        validation_err_messages.append(
            f"param volume_size_gib must be between 4 and 200 (inclusive), but was {volume_size_gib}"
        )

    main_git_repo_ref = kwargs["main_git_repo_ref"]
    if main_git_repo_ref and not project_is_git_based:
        validation_err_messages.append("param main_git_repo_ref is only valid for Git-based Domino projects")
    elif main_git_repo_ref:
        # mirrors basic validation here (but does a little less):
        # https://github.com/cerebrotech/domino/blob/accda099b33eb462149a0f4518101539d682ca10/server/app/domino/server/repositories/Reference.scala#L78
        ref_type = main_git_repo_ref.Type.lower()
        allowed_ref_types = {"head", "branches", "tags", "commitId", "ref"}
        if ref_type not in allowed_ref_types:
            validation_err_messages.append(
                f"param main_git_repo_ref.Type must be one of {allowed_ref_types} but was {ref_type}"
            )
        elif ref_type != "head" and main_git_repo_ref.Value is None:
            # all except head require a value
            validation_err_messages.append(
                f"param main_git_repo_ref.Type \"{ref_type}\" requires main_git_repo_ref.Value, but was None"
            )
    return validation_err_messages


def _validate_incompatible_run_domino_job_task_kwargs(kwargs: Dict[str, Any]) -> List[str]:
    validation_err_messages = []
    # note: later we make a call to get env rev info to build the env rev spec, and raise if env id doesn't correspond to env rev
    if kwargs["environment_name"] is not None and kwargs["environment_id"] is not None:
        validation_err_messages.append(
            "must only provide one of \"environment_name\" or \"environment_id\", but both were provided"
        )
    if kwargs["hardware_tier_name"] is not None and kwargs["hardware_tier_id"] is not None:
        validation_err_messages.append(
            "must only provide one of \"hardware_tier_name\" or \"hardware_tier_id\", but both were provided"
        )
    if kwargs["external_data_volumes"] is not None and kwargs["external_data_volume_ids"] is not None:
        validation_err_messages.append(
            "must only provide one of \"external_data_volumes\" or \"external_data_volume_ids\", but both were provided; "
            "\"external_data_volume_ids\" is accepted for backwards compatibility, but \"external_data_volumes\" is the preferred way"
        )
    return validation_err_messages


def _validate_edvs(kwargs: Dict[str, Any]) -> List[str]:
    external_data_volumes: Optional[List[ExternalDataVolume]] = kwargs.get("external_data_volumes")
    if external_data_volumes:
        num_bad_edvs = sum(1 for edv in external_data_volumes if edv.Id is None and edv.Name is None)
        if num_bad_edvs > 0:
            return [f"An ExternalDataVolume must have at least a Name or Id, but {num_bad_edvs} had neither"]
    return []


def _get_domino_job_config_edv_args(
    flyte_task_name: str,
    provided_external_data_volumes: Optional[List[ExternalDataVolume]],
    provided_external_data_volume_ids: Optional[List[str]],
) -> Optional[List[str]]:
    if provided_external_data_volumes is None and provided_external_data_volume_ids is None:
        # user provided None, meaning "use project defaults", so return None
        return None
    if (provided_external_data_volumes is not None and len(provided_external_data_volumes) == 0) or (
        provided_external_data_volume_ids is not None and len(provided_external_data_volume_ids) == 0
    ):
        # user provided an empty list, meaning "use no EDVs", so return an empty list early to avoid unnecessary API calls
        return []
    available_edvs = _get_project_edvs(flyte_task_name)
    if provided_external_data_volume_ids:
        provided_external_data_volumes = [ExternalDataVolume(Id=edv_id) for edv_id in provided_external_data_volume_ids]
    assert provided_external_data_volumes is not None  # typing help for mypy
    return _resolve_edv_ids(flyte_task_name, provided_external_data_volumes, available_edvs)


def _get_domino_job_config_env_args(
    flyte_task_name: str,
    provided_env_name: Optional[str],
    provided_env_id: Optional[str],
    provided_env_rev_id: Optional[str],
) -> Tuple[Optional[str], Optional[EnvironmentRevisionSpecification]]:
    resolved_env_id = (
        provided_env_id if provided_env_name is None else _resolve_env_id(flyte_task_name, provided_env_name)
    )

    if resolved_env_id is None and provided_env_rev_id is None:
        return (None, None)  # project default env and active rev

    if provided_env_rev_id is None:
        return (resolved_env_id, None)  # active rev of provided env

    # get info about the provided env rev id so we can build the EnvironmentRevisionSpecification needed for the DominoJobConfig()
    # and also get the env id if that was not provided by the user
    env_rev_info = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/environments/environmentRevision/{provided_env_rev_id}",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving environment revision info for environment revision id \"{provided_env_rev_id}\"",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve environment revision info for environment revision id \"{provided_env_rev_id}\"",
    )
    env_rev_spec = EnvironmentRevisionSpecification(
        EnvironmentRevisionType=(
            EnvironmentRevisionType.RestrictedRevision
            if env_rev_info["environmentRevision"]["isRestricted"]
            else EnvironmentRevisionType.SomeRevision
        ),
        EnvironmentRevisionId=provided_env_rev_id,
    )

    if resolved_env_id is None:
        return (env_rev_info["environment"]["id"], env_rev_spec)

    if resolved_env_id != env_rev_info["environment"]["id"]:
        env_resolution_msg = (
            f" (resolved from env name \"{provided_env_name}\")" if provided_env_name is not None else ""
        )
        raise ValueError(
            f"Flyte task \"{flyte_task_name}\": Provided environment revision does not correspond to provided environment. "
            f"Environment revision has env with id {env_rev_info['environment']['id']}, "
            f"but env id is {resolved_env_id}{env_resolution_msg}"
        )
    return (resolved_env_id, env_rev_spec)


def _resolve_env_id(flyte_task_name: str, provided_env_name: str) -> str:
    # user can provide env name instead of env id because that is user friendly.
    # but, env name is not guaranteed unique. so, look up env id from name using domino api.
    # if there's only one env with that name, pretend that the provided_env_id is that one.
    # if there's zero envs or more than one env with that name, raise a helpful exception.
    envs = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/environments/self",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving environment info for env name \"{provided_env_name}\"",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve environment info for env name \"{provided_env_name}\"",
    )
    matching_envs = [env for env in envs if env["name"] == provided_env_name]
    if len(matching_envs) == 0:
        raise ValueError(
            f"Flyte task \"{flyte_task_name}\": User does not have access to env named \"{provided_env_name}\" or it does not exist"
        )
    if len(matching_envs) > 1:
        raise ValueError(
            f"Flyte task \"{flyte_task_name}\": More than one env named \"{provided_env_name}\". Please provide environment_id of the env you want instead of environment_name: {matching_envs}"
        )
    return matching_envs[0]["id"]


def _get_domino_job_config_hardware_tier_args(
    flyte_task_name: str,
    provided_hardware_tier_name: Optional[str],
    provided_hardware_tier_id: Optional[str],
) -> Optional[str]:
    if provided_hardware_tier_name is not None:
        return _resolve_hwt_id(flyte_task_name, provided_hardware_tier_name)
    return provided_hardware_tier_id


def _resolve_hwt_id(flyte_task_name: str, provided_hardware_tier_name: str) -> str:
    # user can provide hwt name instead of id because that is user friendly.
    # but, hwt name is not guaranteed unique. so, look up hwt id from name using domino api.
    # if there's only one hwt with that name, use that one's id.
    # if there's zero hwts or more than one hwt with that name, raise a helpful exception.
    # NOTE: this will have to change if we want support "cross project" tasks. that opens a can though since practitioner user
    # does not have "ViewHardwareTiers" permission required for the broader "get all hardware tiers" endpoint
    hwts = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/projects/{os.environ['DOMINO_PROJECT_ID']}/hardwareTiers",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving info for hardware tier named \"{provided_hardware_tier_name}\"",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve info for hardware tier named \"{provided_hardware_tier_name}\"",
    )
    matching_hwts = [hwt for hwt in hwts if hwt["hardwareTier"]["name"] == provided_hardware_tier_name]
    if len(matching_hwts) == 0:
        raise ValueError(
            f"Flyte task \"{flyte_task_name}\": User does not have access to hardware tier named \"{provided_hardware_tier_name}\" or it does not exist"
        )
    if len(matching_hwts) > 1:
        raise ValueError(
            f"Flyte task \"{flyte_task_name}\": More than one hardware tier named \"{provided_hardware_tier_name}\". Please provide hardware_tier_id of the hardware tier you want instead of hardware_tier_name: {matching_hwts}"
        )
    return matching_hwts[0]["hardwareTier"]["id"]


def _get_domino_job_config_dataset_snapshots_args(
    flyte_task_name: str,
    config_snapshots: Optional[List[DatasetSnapshot]],
) -> Optional[List[DatasetSnapshot]]:
    if not config_snapshots:
        return config_snapshots

    project_id = os.environ['DOMINO_PROJECT_ID']
    project_snapshots = _get_project_snapshots(flyte_task_name, project_id)
    shared_snapshots = _get_shared_snapshots(flyte_task_name, project_id)

    return _resolve_dataset_snapshots(flyte_task_name, config_snapshots, project_snapshots + shared_snapshots)


def _get_project_snapshots(flyte_task_name: str, project_id: str) -> List[DatasetSnapshot]:
    # return from this has dataset name, but not snapshot version numbers
    datasets = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/datasetrw/datasets-v2?projectIdsToInclude={project_id}",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving datasets to resolve info required to use the provided dataset snapshots",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve datasets to resolve info required to use the provided dataset snapshots",
    )
    # return from this has snapshot version numbers, but not name
    # need to combine with datasets to get a DatasetSnapshot()
    snapshots = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/datasetrw/snapshots/project/{project_id}",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving project dataset snapshots used to validate provided dataset snapshots",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve project dataset snapshots used to validate provided dataset snapshots",
    )
    dataset_names = {dataset["datasetRwDto"]["id"]: dataset["datasetRwDto"]["name"] for dataset in datasets}

    return [
        DatasetSnapshot(Id=dataset_id, Name=dataset_names[dataset_id], Version=snapshot["version"])
        for snapshot in snapshots
        # the "if": theoretically possible for 'get snapshots' to return a snapshot with a dataset id that is not in
        # the 'get datasets' return. not sure what to do other than omit it from the list returned from this func.
        if (dataset_id := snapshot["datasetId"]) in dataset_names and snapshot["lifecycleStatus"] == "Active"
    ]


def _get_shared_snapshots(flyte_task_name: str, project_id: str) -> List[DatasetSnapshot]:
    # return from this has both dataset name and snapshot version number
    # only snapshots with active status are returned by the api
    shared_snapshots = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/datasetrw/mounts-v2/{project_id}/shared",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving shared dataset snapshots used to validate provided dataset snapshots",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve shared dataset snapshots used to validate provided dataset snapshots",
    )
    return [
        DatasetSnapshot(Id=snapshot["datasetId"], Name=snapshot["name"], Version=snapshot["versionNumber"])
        for snapshot in shared_snapshots
    ]


def _resolve_dataset_snapshots(
    flyte_task_name: str,
    config_snapshots: List[DatasetSnapshot],
    dataset_snapshots: List[DatasetSnapshot],
) -> List[DatasetSnapshot]:
    resolved_snapshots: List[DatasetSnapshot] = []
    errs: Dict[DatasetSnapshot, str] = {}

    # yes this is n^2 but n will be very small. if it becomes a problem, we can optimize.
    for config_snapshot in config_snapshots:
        if config_snapshot.Id is None and config_snapshot.Name is None:
            errs[config_snapshot] = "Dataset snapshot must have at least an Id or Name."
            continue
        if config_snapshot.Version is not None and config_snapshot.Version < 1:
            errs[config_snapshot] = "Dataset snapshot version must be greater than 0."
            continue

        resolved_snapshot = _resolve_dataset_snapshot(flyte_task_name, config_snapshot, dataset_snapshots, errs)
        if resolved_snapshot is not None:
            resolved_snapshots.append(resolved_snapshot)

    _check_multiple_snapshots_per_dataset(resolved_snapshots, errs)

    if errs:
        errors = "\n".join([f"* {snapshot}: {error_message}" for snapshot, error_message in errs.items()])
        raise ValueError(f'Flyte task "{flyte_task_name}":\n{errors}')

    return resolved_snapshots


def _resolve_dataset_snapshot(
    flyte_task_name: str,
    config_snapshot: DatasetSnapshot,
    dataset_snapshots: List[DatasetSnapshot],
    errs: Dict[DatasetSnapshot, str],
) -> Optional[DatasetSnapshot]:
    # Resolve by dataset id and name into a list of candidates
    result = _resolve_dataset_snapshot_id_name(config_snapshot, dataset_snapshots, errs)

    if result is None:
        return None

    candidate_snapshots, id_mismatch_snapshots = result

    # Resolve by snapshot version if candidates exist
    if candidate_snapshots:
        return _resolve_dataset_snapshot_version(flyte_task_name, config_snapshot, candidate_snapshots, errs)

    # Handle id mismatch if no candidates were found
    if id_mismatch_snapshots:
        errs[config_snapshot] = dataset_id_mismatch_error(id_mismatch_snapshots)
    else:
        errs[config_snapshot] = "No matching dataset by id or name."

    return None


# 1. A dataset snapshot is considered a candidate if:
#    a. Both id and name match those of the config snapshot
#    b. Id matches but the config snapshot name is None
#    c. Name matches but the config snapshot id is None
#
# 2. If the dataset id of the config snapshot matches but the name does not, flag that as an error and return.
#
# 3. If Name matches but config snapshot id is not None and does not match, the id is incorrect.  Add the
#    dataset snapshot to 'id_mismatch_snapshots' as a list of suggestions for correction.
#
def _resolve_dataset_snapshot_id_name(
    config_snapshot: DatasetSnapshot,
    dataset_snapshots: List[DatasetSnapshot],
    errs: Dict[DatasetSnapshot, str],
) -> Optional[Tuple[List[DatasetSnapshot], List[DatasetSnapshot]]]:
    candidate_snapshots: List[DatasetSnapshot] = []
    id_mismatch_snapshots: List[DatasetSnapshot] = []

    for dataset_snapshot in dataset_snapshots:
        name_match = config_snapshot.Name == dataset_snapshot.Name
        if config_snapshot.Id is not None:
            # Match by id
            if config_snapshot.Id == dataset_snapshot.Id:
                if name_match or config_snapshot.Name is None:
                    candidate_snapshots.append(dataset_snapshot)
                else:
                    # Dataset id match but name mismatch
                    errs[config_snapshot] = (
                        f"Dataset name mismatch. "
                        f"Resolve by replacing '{config_snapshot.Name}' with '{dataset_snapshot.Name}'."
                    )
                    return None
            elif name_match:
                # Dataset name match but id mismatch
                id_mismatch_snapshots.append(dataset_snapshot)
        elif name_match:
            # Match by name
            candidate_snapshots.append(dataset_snapshot)

    return candidate_snapshots, id_mismatch_snapshots


def _resolve_dataset_snapshot_version(
    flyte_task_name: str,
    config_snapshot: DatasetSnapshot,
    candidate_snapshots: List[DatasetSnapshot],
    errs: Dict[DatasetSnapshot, str],
) -> Optional[DatasetSnapshot]:
    if config_snapshot.Version:
        return _resolve_dataset_snapshot_version_exists(config_snapshot, candidate_snapshots, errs)
    else:
        return _resolve_dataset_snapshot_version_none(flyte_task_name, config_snapshot, candidate_snapshots, errs)


def _resolve_dataset_snapshot_version_exists(
    config_snapshot: DatasetSnapshot,
    candidate_snapshots: List[DatasetSnapshot],
    errs: Dict[DatasetSnapshot, str],
) -> Optional[DatasetSnapshot]:
    # Filter candidate snapshots matching the config snapshot version
    matched_snapshots = [snapshot for snapshot in candidate_snapshots if snapshot.Version == config_snapshot.Version]

    if len(matched_snapshots) == 1:
        return matched_snapshots[0]
    elif len(matched_snapshots) > 1:
        errs[config_snapshot] = multiple_dataset_match_error(matched_snapshots)
    else:
        errs[config_snapshot] = f"Dataset snapshot version {config_snapshot.Version} not found."

    return None


def _resolve_dataset_snapshot_version_none(
    flyte_task_name: str,
    config_snapshot: DatasetSnapshot,
    candidate_snapshots: List[DatasetSnapshot],
    errs: Dict[DatasetSnapshot, str],
) -> Optional[DatasetSnapshot]:
    # Filter candidate snapshots with version 0
    version_0_snapshots = [snapshot for snapshot in candidate_snapshots if snapshot.Version == 0]

    # Having more than one version 0 snapshot implies that there are multiple datasets that match by name
    if len(version_0_snapshots) > 1:
        errs[config_snapshot] = multiple_dataset_match_error(version_0_snapshots)
        return None

    # Find the snapshot with the max version
    max_version_snapshot = max(
        candidate_snapshots,
        key=lambda snapshot: snapshot.Version if snapshot.Version is not None else 0,
    )

    # Handle case where max version is 0, indicating no active snapshots
    if max_version_snapshot.Version == 0:
        errs[config_snapshot] = "Dataset does not have any snapshots."
        return None

    # Display a warning about no version provided
    click.secho(
        f"Flyte task \"{flyte_task_name}\": "
        f"Warning: no version provided for dataset snapshot {config_snapshot}, "
        f"so defaulting to latest version {max_version_snapshot.Version}. "
        f"For reproducibility and predictability, it's best to provide a version.",
        fg="yellow",
    )

    return max_version_snapshot


def _check_multiple_snapshots_per_dataset(resolved_snapshots: List[DatasetSnapshot], errs: Dict[DatasetSnapshot, str]):
    grouped_snapshots: Dict[str, List[DatasetSnapshot]] = defaultdict(list)
    for snapshot in resolved_snapshots:
        assert snapshot.Id is not None  # typing help for mypy
        grouped_snapshots[snapshot.Id].append(snapshot)
    for group in grouped_snapshots.values():
        count = len(group)
        if count > 1:
            for snapshot in group:
                errs[snapshot] = f"Only one snapshot per dataset can be provided, but there are {count}."


def dataset_id_mismatch_error(snapshots: List[DatasetSnapshot]) -> str:
    datasets = [snapshot.to_dataset_id_and_name() for snapshot in snapshots]
    unique_datasets = [dict(t) for t in {tuple(d.items()) for d in datasets}]
    return (
        f"Dataset snapshot matches by name but not by id. "
        f"Resolve by using one of the matched dataset ids from: {unique_datasets}."
    )


def multiple_dataset_match_error(snapshots: List[DatasetSnapshot]) -> str:
    datasets = [snapshot.to_dataset_id_and_name() for snapshot in snapshots]
    return (
        f"Dataset snapshot matches more than one dataset by name. "
        f"Resolve by using one of the matched dataset ids from: {datasets}."
    )


def _get_project_edvs(flyte_task_name: str) -> List[ExternalDataVolume]:
    all_project_edvs = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/datamount/projects/{os.environ['DOMINO_PROJECT_ID']}",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving edvs to resolve info required to use the provided edvs",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve edvs to resolve info required to use the provided edvs",
    )
    inaccessible_project_edvs = _get_json_response(
        f"{os.environ['DOMINO_API_PROXY']}/v4/datamount/projects/inaccessible/{os.environ['DOMINO_PROJECT_ID']}",
        f"Flyte task \"{flyte_task_name}\": Connection problem retrieving inaccessible edvs to resolve info required to use the provided edvs",
        f"Flyte task \"{flyte_task_name}\": Failed to retrieve inaccessible edvs to resolve info required to use the provided edvs",
    )
    inaccessible_ids = {edv["id"] for edv in inaccessible_project_edvs}
    return [
        ExternalDataVolume(Id=edv["id"], Name=edv["name"])
        for edv in all_project_edvs
        if edv["id"] not in inaccessible_ids
    ]


def _resolve_edv_ids(
    flyte_task_name: str, provided_edvs: List[ExternalDataVolume], available_edvs: List[ExternalDataVolume]
) -> List[str]:
    available_edv_id_to_name = {}
    available_edv_name_to_ids = defaultdict(set)
    for edv in available_edvs:
        available_edv_id_to_name[edv.Id] = edv.Name
        available_edv_name_to_ids[edv.Name].add(edv.Id)
    resolved_edv_ids = []
    bad_edv_errors = []
    for edv in provided_edvs:
        # already validated that each provided has at least a Name or Id
        if edv.Id is not None:
            actual_name = available_edv_id_to_name.get(edv.Id)
            if actual_name is None:
                bad_edv_errors.append(
                    f"Provided edv id {edv.Id} either does not exist in this project or the user does not have access to it"
                )
                continue
            if edv.Name is not None and actual_name != edv.Name:
                bad_edv_errors.append(
                    f"Provided edv id {edv.Id} with name {edv.Name}, but this edv id has name {actual_name}"
                )
                continue
            resolved_edv_ids.append(edv.Id)
        else:
            matching_edv_ids = available_edv_name_to_ids.get(edv.Name)
            if not matching_edv_ids:
                bad_edv_errors.append(
                    f"Provided edv name {edv.Name} either does not exist in this project or the user does not have access to it"
                )
                continue
            if len(matching_edv_ids) > 1:
                bad_edv_errors.append(
                    f"Provided edv name {edv.Name}, but more than one edv with that name exists in this project. Specify the id with this edv. Possible ids for this name: {matching_edv_ids}"
                )
                continue
            matched_id = matching_edv_ids.pop()
            assert matched_id  # typing help for mypy
            resolved_edv_ids.append(matched_id)
    if bad_edv_errors:
        bad_edv_errors.append(f"Available EDVs: {available_edvs}")
        bad_edv_errors.insert(0, f"Flyte task \"{flyte_task_name}\":")
        err_msg = "\n* ".join(bad_edv_errors)
        raise ValueError(err_msg)
    return resolved_edv_ids


def _get_json_response(url: str, connection_error_msg: str, response_code_error_msg: str) -> Any:
    try:
        response = requests.get(url)
    except requests.exceptions.RequestException as err:
        raise requests.exceptions.RequestException(connection_error_msg) from err
    if response.status_code != 200:
        raise DominoFlyteException(f"{response_code_error_msg} (StatusCode {response.status_code}): {response.text})")
    return response.json()
