from typing import List, Union
from urllib.parse import urlparse

import rich_click
from flytekit.configuration.plugin import FlytekitPlugin
from flytekit.core.base_task import PythonTask
from flytekit.core.python_auto_container import PythonAutoContainerTask
from flytekit.core.workflow import WorkflowBase
from flytekit.remote.executions import (
    FlyteNodeExecution,
    FlyteTaskExecution,
    FlyteWorkflowExecution,
)

LABEL_DOMINO_USER_NAME = "dominodatalab.com/starting-user-username"
LABEL_PROJECT_NAME = "dominodatalab.com/project-name"


class DominoJobPlugin(FlytekitPlugin):
    @staticmethod
    def get_additional_context_for_version_hash(entity: Union[PythonAutoContainerTask, WorkflowBase]) -> List[str]:
        """
        Get additional context to be used for calculating the version hash.

        In particular, for DominoJobTask workflows to register without error, we include the task configs into the
        additional context used for the version hash. This solves the edge case where two workflows with the same
        version hash but different task configs (e.g. different commit id) causes a "task with different structure
        already exists" error.
        """
        if isinstance(entity, PythonTask):
            return [str(entity.task_config)]
        if isinstance(entity, WorkflowBase):
            task_configs = []
            for n in entity.nodes:
                task_configs.extend(DominoJobPlugin.get_additional_context_for_version_hash(n.flyte_entity))
            return task_configs
        return []

    @staticmethod
    def get_additional_info_for_execution(
        console_http_domain: str, entity: Union[FlyteWorkflowExecution, FlyteNodeExecution, FlyteTaskExecution]
    ) -> str:
        """
        Get additional info for a given execution. Useful to pass in additional urls.

        Here, we return a Domino UI link when it is a Domino workflow
        """
        label_dict = (entity.spec and entity.spec.labels and entity.spec.labels.values) or dict()
        project_owner_name = label_dict.get(LABEL_DOMINO_USER_NAME)
        project_name = label_dict.get(LABEL_PROJECT_NAME)

        if project_owner_name is None or project_name is None:
            # It is not a Domino workflow, so do not generate a Domino UI link
            return ""
        execution_name = entity.id.name
        path = f"/u/{project_owner_name}/{project_name}/flows/redirect/{execution_name}"
        url = urlparse(console_http_domain)._replace(path=path).geturl()

        return "\n    Go to " + rich_click.style(url, fg="cyan") + " to see the execution in Domino."
