from domino._impl.custommetrics.paths.api_metric_values_v1.post import ApiForpost


class ApiMetricValuesV1(
    ApiForpost,
):
    pass
