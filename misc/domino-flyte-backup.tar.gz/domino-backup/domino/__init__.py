__all__ = ["Domino", "__version__"]

from domino._version import __version__

from .domino import Domino
