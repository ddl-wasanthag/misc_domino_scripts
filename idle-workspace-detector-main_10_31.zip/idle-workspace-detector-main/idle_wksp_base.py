import csv
import os
import pandas as pd
from pathlib import Path
import requests
from pymongo import MongoClient
import notifications
import logging
from datetime import datetime

if os.environ["DOMINO_IS_GIT_BASED"].lower() == 'true':
    DATASET_PATH = "/mnt/data/" + os.environ["DOMINO_PROJECT_NAME"]
else:
    DATASET_PATH = "/domino/datasets/local/" + os.environ["DOMINO_PROJECT_NAME"]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    force=True
)
logger = logging.getLogger(__name__)

IDLE_WORKSPACE_CSV_PATH = f"{DATASET_PATH}/data/idle_workspaces.csv"
ALLOW_LIST_PATH = f"{DATASET_PATH}/data/allowlist.csv"


class IdleWorkspacesBase:
    def __init__(self, config):
        platform_namespace = config["domino_platform_namespace"]
        # Create the MongoDB client
        client = MongoClient(
            "mongodb://mongodb-replicaset.{}.svc.cluster.local:27017".format(
                platform_namespace
            ),
            username=os.environ["MONGODB_USERNAME"],
            password=os.environ["MONGODB_PASSWORD"],
            authSource="domino",
            authMechanism="SCRAM-SHA-1",
        )

        self.db = client["domino"]
        self.config = config
        # Information for Domino API calls
        self.header = {"X-Domino-Api-Key": os.environ["DOMINO_USER_API_KEY"]}
        self.domino_api_host = os.environ["DOMINO_API_HOST"]
        self.dry_run_prefix = "DRY RUN - "

    # Create the idle_workspaces csv if it does not exist.
    def init_idle_csv(self):
        with open(IDLE_WORKSPACE_CSV_PATH, "w") as csvfile:
            writer = csv.writer(csvfile, delimiter=",")
            writer.writerow(
                [
                    "WorkspaceId",
                    "WorkspaceName",
                    "OwnerId",
                    "SessionId",
                    "ProjectId",
                    "IdleTime",
                ]
            )

    # Create the allowlist csv if it down not exist.
    def init_allow_csv(self):
        with open(ALLOW_LIST_PATH, "w") as csvfile:
            writer = csv.writer(csvfile, delimiter=",")
            writer.writerow(["UserId", "ProjectId"])

    def init_all(self):
        if not Path(f"{DATASET_PATH}/data").is_dir():
            os.mkdir(f"{DATASET_PATH}/data")

        if not Path(IDLE_WORKSPACE_CSV_PATH).is_file():
            self.init_idle_csv()

        if not Path(ALLOW_LIST_PATH).is_file():
            self.init_allow_csv()

    def does_workspace_contain_attached_cluster(self, workspace_session_id, project_id):
        session_url = "{}/v4/workspace/{}/computeClusterStatus?projectId={}".format(
            self.domino_api_host,
            workspace_session_id,
            project_id,
        )
        try:
            sessions = requests.get(session_url, headers=self.header)
        except requests.exceptions.ConnectionError as e:
            print(f"Error fetching compute cluster status: {e}")
            return False  # Return False if there's an error

        if sessions.status_code == 200:
            if sessions.text == "null":
                return False

            try:
                data = sessions.json()
                # Check if 'clusterState' is in the parsed JSON
                if "clusterState" in data:
                    # clusterState can have values {Starting, Ready, Stopping, NonExistent}
                    return True
            except ValueError:
                print("Error decoding JSON")
                return False  # Return False if JSON decoding fails

        return False  # Default to returning False for other cases

    # Check if the last 30 minutes of usage classify the workspace as idle.
    def get_last_30_min_entries(self, entries):
        current_time = datetime.now().timestamp() * 1000
        # Subtract 30 minutes
        timestamp_30_minutes_ago = current_time - (30 * 60 * 1000)
        return entries[entries["timestamp"] > timestamp_30_minutes_ago]

    def parse_usage(self, response):
        entries = pd.DataFrame(response.json()["snapshots"])
        if "cpu" not in entries.columns or "memory" not in entries.columns:
            return False
        entries = self.get_last_30_min_entries(entries)
        cpu_avg = entries["cpu"].mean()
        cpu_sd = entries["cpu"].std()
        memory_avg = entries["memory"].mean() / 1000000000
        memory_sd = entries["memory"].std() / 1000000000
        logger.debug(
            "\nActual CPU Avg {}:Config CPU Avg {},\nActual CPU Std Dev {}:Config CPU Std Dev{},\nActual Mem Avg{}:Config Mem Avg{},\nActual Mem Std Dev{}:Config Mem Std Dev{}".format(
                cpu_avg,
                self.config["idle"]["average_cpu_limit_pct"],
                cpu_sd,
                self.config["idle"]["cpu_std_deviation"],
                memory_avg,
                self.config["idle"]["average_memory_limit_gib"],
                memory_sd,
                self.config["idle"]["mem_std_deviation"],
            )
        )
        return (
            cpu_avg < self.config["idle"]["average_cpu_limit_pct"]
            and cpu_sd < self.config["idle"]["cpu_std_deviation"]
            and memory_avg < self.config["idle"]["average_memory_limit_gib"]
            and memory_sd < self.config["idle"]["mem_std_deviation"]
        )

    # Removes a workspace from the idle_workspaces csv tracker.
    def remove_if_no_longer_idle(self, session):
        idle_workspaces = pd.read_csv(IDLE_WORKSPACE_CSV_PATH)
        idle_workspaces = idle_workspaces[idle_workspaces.SessionId != session]
        idle_workspaces.to_csv(IDLE_WORKSPACE_CSV_PATH, sep=",", index=False)

    # When an idle workspace is found, add or increment the idle_workspace
    # tracker.
    def handle_idle_workspace(self, workspace_session):
        idle_workspaces = pd.read_csv(IDLE_WORKSPACE_CSV_PATH)
        session = workspace_session["_id"]
        if session in set(idle_workspaces["SessionId"]):
            current_idle = idle_workspaces.loc[idle_workspaces["SessionId"] == session][
                "IdleTime"
            ].values[0]
            idle_workspaces.loc[idle_workspaces["SessionId"] == session, "IdleTime"] = (
                current_idle + 0.5
            )
        else:
            idle_workspaces.loc[len(idle_workspaces.index)] = [
                workspace_session["workspaceId"],
                workspace_session["workspaceName"],
                workspace_session["ownerId"],
                session,
                workspace_session["projectId"],
                0.5,
            ]
        idle_workspaces.to_csv(IDLE_WORKSPACE_CSV_PATH, sep=",", index=False)

    def get_recipient_email(self, user):
        return self.config["notify"]["admins"]

    def shutdown_or_warn(self):
        projects = pd.DataFrame.from_records(list(self.db.projects.find()))
        users = pd.DataFrame.from_records(list(self.db.users.find()))
        projects["_id"] = projects["_id"].apply(lambda x: str(x))
        users["_id"] = users["_id"].apply(lambda x: str(x))
        idle_workspaces = pd.read_csv(IDLE_WORKSPACE_CSV_PATH)
        idle_workspaces = idle_workspaces[
            idle_workspaces["IdleTime"] >= self.config["idle"]["warning_interval_hours"]
        ]
        for idx, workspace in idle_workspaces.iterrows():
            project_name = projects.loc[projects["_id"] == workspace["ProjectId"]].iloc[
                0
            ]["name"]
            user = users.loc[users["_id"] == workspace["OwnerId"]].iloc[0]
            username = user["loginId"]["id"]
            to_addr = self.get_recipient_email(user)
            if workspace["IdleTime"] >= self.config["idle"]["shutdown_after_hours"]:
                if self.shutdown_workspace(workspace):
                    self.log_workspace_shutdown(workspace, project_name, username)
                    email = notifications.format_stopped_email(
                        self.config,
                        workspace["WorkspaceName"],
                        project_name,
                        username,
                    )
                    email_subject = self.dry_run_prefix + "Idle Workspace Shutdown"
                    notifications.send_email(self.config, to_addr, email, email_subject)

                    idle_workspaces.drop(idx, inplace=True)
                    idle_workspaces.to_csv(
                        IDLE_WORKSPACE_CSV_PATH, sep=",", index=False
                    )
            elif (
                workspace["IdleTime"] % self.config["idle"]["warning_interval_hours"]
                == 0
            ):
                email = notifications.format_warning_email(
                    self.config,
                    workspace["WorkspaceName"],
                    project_name,
                    username,
                )
                email_subject = self.dry_run_prefix + "Idle Running Workspace Reminder"
                notifications.send_email(self.config, to_addr, email, email_subject)

    def filter_idle_allowed(self, running_workspace_sessions: pd.DataFrame):
        allowlist = pd.read_csv(ALLOW_LIST_PATH)
        allowed = running_workspace_sessions.merge(
            allowlist,
            how="left",
            left_on=["projectId", "ownerId"],
            right_on=["ProjectId", "UserId"],
            suffixes=(),
            indicator=True,
        )
        idle_not_allowed = allowed.loc[allowed["_merge"] == "left_only"]
        idle_not_allowed = idle_not_allowed.drop(
            columns=["_merge", "UserId", "ProjectId"]
        )
        return idle_not_allowed

    def check_and_update_idle_wksp(self, running_workspace_sessions: pd.DataFrame):
        for _, workspace_session in running_workspace_sessions.iterrows():

            # check if admin wants workspaces with attached clusters to be ignored
            if self.config["idle"]["ignore_workspaces_with_attached_cluster"] is True:
                # if this workspace contains an attached cluster, ignore the workspace from removal for now
                if self.does_workspace_contain_attached_cluster(
                    workspace_session["_id"], workspace_session["projectId"]
                ):
                    self.remove_if_no_longer_idle(workspace_session["_id"])
                    continue

            url = "{}/v4/workspace/{}/usage?projectId={}".format(
                self.domino_api_host,
                workspace_session["_id"],
                workspace_session["projectId"],
            )
            usage = requests.get(url, headers=self.header)
            if usage.status_code != 200:
                continue
            if self.parse_usage(usage):
                self.handle_idle_workspace(workspace_session)
            else:
                self.remove_if_no_longer_idle(workspace_session["_id"])

    # checks if each session in the idle list is still running. If not, remove it from the list
    def remove_non_running_workspace_sessions_from_idle_list(self):
        idle_workspaces = pd.read_csv(IDLE_WORKSPACE_CSV_PATH)
        for _, workspace_session in idle_workspaces.iterrows():
            session_url = "{}/v4/workspace/project/{}/sessions/{}".format(
                self.domino_api_host,
                workspace_session["ProjectId"],
                workspace_session["SessionId"],
            )
            try:
                session = requests.get(session_url, headers=self.header)
                session = session.json()
                if (
                    session.get("sessionStatusInfo", {}).get(
                        "rawExecutionDisplayStatus"
                    )
                    != "Running"
                ):
                    self.remove_if_no_longer_idle(session["id"])
            except requests.exceptions.ConnectionError:
                print(
                    "Exception while getting workspace session details, url: "
                    + session_url
                )
                continue

    def process_idle_workspaces(self):
        self.init_all()
        self.remove_non_running_workspace_sessions_from_idle_list()

        workspaces = pd.DataFrame.from_records(
            list(
                self.db.workspace.find(
                    {}, {"_id": 1, "projectId": 1, "ownerId": 1, "name": 1}
                )
            )
        )

        # convert Object("id") to plain id
        workspaces["_id"] = workspaces["_id"].apply(lambda x: str(x))
        workspaces.rename(columns={"_id": "workspaceId"}, inplace=True)
        workspaces.rename(columns={"name": "workspaceName"}, inplace=True)

        running_workspace_sessions = pd.DataFrame.from_records(
            list(
                self.db.workspace_session.find({"rawExecutionDisplayStatus": "Running"})
            )
        )

        # convert Object("id") to plain id
        running_workspace_sessions["_id"] = running_workspace_sessions["_id"].apply(
            lambda x: str(x)
        )

        running_workspace_sessions["workspaceId"] = running_workspace_sessions[
            "workspaceId"
        ].apply(lambda x: str(x))

        # running_workspace_sessions df does not have owner id or project id which is needed in idle workspaces.csv
        running_workspace_sessions = pd.merge(
            running_workspace_sessions, workspaces, on="workspaceId", how="left"
        )
        running_workspace_sessions["ownerId"] = running_workspace_sessions[
            "ownerId"
        ].apply(lambda x: str(x))
        running_workspace_sessions["projectId"] = running_workspace_sessions[
            "projectId"
        ].apply(lambda x: str(x))

        # Checks if workspace is in the allowlist, then checks usage and adds
        # to idle_workspaces csv accordingly.
        running_workspace_sessions = self.filter_idle_allowed(
            running_workspace_sessions
        )
        self.check_and_update_idle_wksp(running_workspace_sessions)

        # Check idle workspaces and address accordingly.
        self.shutdown_or_warn()

    def shutdown_workspace(self, workspace):
        return True

    def log_workspace_shutdown(self, workspace, project_name, username):
        log_file = (
            DATASET_PATH + "/data/" + self.dry_run_prefix + "Workspace_Shutdown_Log.csv"
        )
        file_exists = os.path.isfile(log_file)

        with open(log_file, mode="a", newline="") as file:
            fieldnames = [
                "WorkspaceId",
                "WorkspaceName",
                "OwnerId",
                "OwnerName",
                "SessionId",
                "ProjectId",
                "ProjectName",
                "Timestamp",
            ]
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            if not file_exists:
                writer.writeheader()  # file doesn't exist yet, write a header

            writer.writerow(
                {
                    "WorkspaceId": workspace["WorkspaceId"],
                    "WorkspaceName": workspace["WorkspaceName"],
                    "OwnerId": workspace["OwnerId"],
                    "OwnerName": username,
                    "SessionId": workspace["SessionId"],
                    "ProjectId": workspace["ProjectId"],
                    "projectName": project_name,
                    "Timestamp": datetime.now().isoformat(),
                }
            )
