from idle_wksp_active import IdleWorkspacesActive
from idle_wksp_base import IdleWorkspacesBase
import argparse
import yaml

if __name__ == "__main__":
    # Collect all workspaces and parse.
    parser = argparse.ArgumentParser(
        prog="check_idle_workspaces",
        description="Look for idle workspaces, stop them and notify users",
        epilog="",
    )
    parser.add_argument("--live-run", action="store_true")
    args = parser.parse_args()
    with open("config.yaml", "r") as file:
        config = yaml.safe_load(file)
    idlers = None
    if args.live_run:
        idlers = IdleWorkspacesActive(config)
    else:
        idlers = IdleWorkspacesBase(config)
    idlers.process_idle_workspaces()
