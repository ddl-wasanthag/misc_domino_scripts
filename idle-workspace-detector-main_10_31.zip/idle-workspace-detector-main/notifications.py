import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
import os
import logging

if os.environ["DOMINO_IS_GIT_BASED"].lower() == 'true':
    DATASET_PATH = "/mnt/data/" + os.environ["DOMINO_PROJECT_NAME"]
else:
    DATASET_PATH = "/domino/datasets/local/" + os.environ["DOMINO_PROJECT_NAME"]

if not Path(f"{DATASET_PATH}/data").is_dir():
    os.mkdir(f"{DATASET_PATH}/data")

# Configure logging
logging.basicConfig(
    filename=DATASET_PATH + "/data/sent_emails.log",  # Log file
    level=logging.INFO,  # Set log level to INFO
    format="%(asctime)s - %(levelname)s - %(message)s",  # Log message format
    force=True
)


# Create the email alerting the user that the workspace has been stopped.
def format_stopped_email(
    config, workspace_name, project_name, workspace_owner_username
):
    workspace_message = 'Workspace "{}" - https://{}/workspace/{}/{}'.format(
        workspace_name,
        config["domino_domain"],
        workspace_owner_username,
        project_name,
    )

    email_text = Path("stopped_email.txt").read_text()
    email_html = Path("stopped_email.html").read_text()

    email_html = email_html.replace(
        "$WORKSPACE_MESSAGE", "".join(workspace_message)
    ).replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))
    email_text = email_text.replace(
        "$WORKSPACE_MESSAGE", "".join(workspace_message)
    ).replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))

    return dict(html=email_html, text=email_text)


# Creates the email warning the user that the workspace is idle for more
# than 4 hours.
def format_warning_email(
    config, workspace_name, project_name, workspace_owner_username
):
    workspace_message = 'Workspace "{}" - https://{}/workspace/{}/{}'.format(
        workspace_name,
        config["domino_domain"],
        workspace_owner_username,
        project_name,
    )

    email_text = Path("warning_email.txt").read_text()
    email_html = Path("warning_email.html").read_text()

    email_html = (
        email_html.replace("$WORKSPACE_MESSAGE", "".join(workspace_message))
        .replace("$WARNING_INTERVAL", str(config["idle"]["warning_interval_hours"]))
        .replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))
    )

    email_text = (
        email_text.replace("$WORKSPACE_MESSAGE", "".join(workspace_message))
        .replace("$WARNING_INTERVAL", str(config["idle"]["warning_interval_hours"]))
        .replace("$SHUTDOWN_AFTER", str(config["idle"]["shutdown_after_hours"]))
    )

    return dict(html=email_html, text=email_text)


# Sends an email to the to address with the contents built from the format functions.
def send_email(config, to, contents, subject):
    # Create message container - the correct MIME type is multipart/alternative.
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = config["notify"]["from_email"]
    msg["To"] = to

    # Record the MIME types of both parts - text/plain and text/html.
    part1 = MIMEText(contents["text"], "plain")
    part2 = MIMEText(contents["html"], "html")

    # Attach parts into message container.
    msg.attach(part1)
    msg.attach(part2)

    try:
        # Send the message via local SMTP server.
        s = smtplib.SMTP(config["notify"]["smtp_host"], config["notify"]["smtp_port"])
        s.ehlo()
        s.starttls()
        s.ehlo()

        smtp_user = os.getenv("SMTP_USERNAME", None)
        smtp_password = os.getenv("SMTP_PASSWORD", None)

        if smtp_user and smtp_password:
            s.login(smtp_user, smtp_password)

        # Send the email
        s.sendmail(msg["From"], msg["To"].split(","), msg.as_string())
        logging.info(f"Email sent successfully to {msg['To']}")

    except Exception as e:
        logging.error(f"Failed to send email to {msg['To']}: {e}")
    finally:
        s.quit()
